-----------------------------------------------------------------------------------
------LEAGUE_OF_LEGENDS_CHAMPIONS_INFO_SEASON_13--TABLE
-------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------
-------- CONTENTS
-----------------------------------------------------------------------------------------------------------
/*
AA1		TABLE_CREATION
AA2     TABLE_UPDATES

*/
-----------------------------------------------------------------------------------
--AA1-TABLE_CREATION
-----------------------------------------------------------------------------------
CREATE TABLE student.aa_lol_champs( 
	YEAR YEAR,
	Patch NUMERIC,
	Champion varchar(50),
	Region TEXT,
	Species TEXT,
	CLASS varchar(30),
	ROLE varchar(10),
	Tier varchar (5),
	Score NUMERIC,
	Win_Rate NUMERIC,
	Pick_Rate NUMERIC,
	Ban_Rate NUMERIC,
	Avg_KDA numeric
)
;
-----------------------------------------------------------------------------------------
--AA2-TABLE_UPDATES
------------------------------------------------------------------------------------------
--View Table
SELECT 
	*
FROM 
	student.aa_lol_champs alc 
;
ALTER TABLE student.aa_lol_champs 
RENAME COLUMN score TO rating;
