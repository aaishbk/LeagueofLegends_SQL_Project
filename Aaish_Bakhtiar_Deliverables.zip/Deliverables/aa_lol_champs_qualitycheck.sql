-----------------------------------------------------------------------------------
------LEAGUE_OF_LEGENDS_CHAMPIONS_INFO_SEASON_13--QUALITY-CHECKS
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-------- CONTENTS
-----------------------------------------------------------------------------------
/*
AA1		Viewing Table Contents
AA2     Row Count
AA3		Column Count
AA4		Null Check
*/
-----------------------------------------------------------------------------------
--AA1 - Viewing Table Contents
-----------------------------------------------------------------------------------
SELECT 
	*
FROM 
	student.aa_lol_champs AS alc
;
-----------------------------------------------------------------------------------
--AA2 - Row Count
-----------------------------------------------------------------------------------
SELECT 
	count(*) AS No_Of_Rows
FROM 
	student.aa_lol_champs AS alc 
;
-----------------------------------------------------------------------------------
--AA3 - Column Count
-----------------------------------------------------------------------------------
SELECT
	count(*) AS No_of_Columns
FROM 
	information_schema.columns
WHERE 
	table_name = 'aa_lol_champs' AND table_schema = 'student'
;
-----------------------------------------------------------------------------------
--AA4 - Sum of Column Sums
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-- Numerical columns identifier with ,
-----------------------------------------------------------------------------------
SELECT 
    'SUM(DISTINCT ' || column_name || ') AS ' || column_name || '_sum,'
FROM 
    information_schema.COLUMNS
WHERE 
    table_schema = 'student' 
AND 
    table_name = 'aa_lol_champs' 
AND 
    data_type IN ('integer', 'numeric')
;
-----------------------------------------------------------------------------------
-- Numerical columns identifier with +
-----------------------------------------------------------------------------------
SELECT 
    'SUM(DISTINCT ' || column_name || ')+ '
FROM 
    information_schema.COLUMNS
WHERE 
    table_schema = 'student' 
AND 
    table_name = 'aa_lol_champs' 
AND 
    data_type IN ('integer', 'numeric')
;
-----------------------------------------------------------------------------------
-- Sum of Column Sums
-----------------------------------------------------------------------------------
SELECT 
	SUM(DISTINCT year) AS year_sum,
	SUM(DISTINCT patch) AS patch_sum,
	SUM(DISTINCT rating) AS rating_sum,
	SUM(DISTINCT win_rate) AS win_rate_sum,
	SUM(DISTINCT pick_rate) AS pick_rate_sum,
	SUM(DISTINCT ban_rate) AS ban_rate_sum,
	SUM(DISTINCT avg_kda) AS avg_kda_sum,
	SUM(DISTINCT year)+ 
	SUM(DISTINCT patch)+ 
	SUM(DISTINCT rating)+ 
	SUM(DISTINCT win_rate)+ 
	SUM(DISTINCT pick_rate)+ 
	SUM(DISTINCT ban_rate)+ 
	SUM(DISTINCT avg_kda) AS Sum_Of_Column_Sums
FROM
	student.aa_lol_champs alc
;
-----------------------------------------------------------------------------------
--AA4 - Null Check
-----------------------------------------------------------------------------------
SELECT 
	count(*)
FROM
	student.aa_lol_champs AS alc
WHERE 
	"year" IS NULL OR
	patch IS NULL OR
	champion IS NULL OR
	region IS NULL OR
	species IS NULL OR
	"class" IS NULL OR
	"role" IS NULL OR
	tier IS NULL OR
	rating IS NULL OR
	win_rate IS NULL OR
	pick_rate IS NULL OR
	ban_rate IS NULL OR
	avg_kda IS NULL
;
