-----------------------------------------------------------------------------------
------LEAGUE_OF_LEGENDS_CHAMPIONS_INFO_SEASON_13--QUERIES
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-------- CONTENTS
-----------------------------------------------------------------------------------
/*
 *
AA1		Viewing Table Contents
AA2     How many champions are there?
AA3		How many champions are from each region?
AA4		How many champions from each species class?
AA5		What are the different species in Ionia?
AA6		Who are the Darkin and Aspect Champions?
AA7		What region has the lowest number of champions?
AA8		What are the different classes and how many champions are in each class?
AA9		Who are all the highest tier champions in the oldest patch?
AA10	What roles have the highest popularity from all the patches in 2023?
AA11	Can you name the lowest winrate champion for each patch?
AA12	Which champions had an average rating above 70 in 2023?
AA13	Which champions had positive winrate in the latest patch?
AA14	Which champions winrate increased by atleast 10% over patches?
AA15	Which species in each regions are most played and least played?
 *
*/
-----------------------------------------------------------------------------------
--AA1 - Viewing Table Contents
-----------------------------------------------------------------------------------
SELECT 
	*
FROM 
	student.aa_lol_champs AS alc
;
-----------------------------------------------------------------------------------
--AA2 - How many champions are there?
-----------------------------------------------------------------------------------
SELECT 
	count(DISTINCT champion) AS No_Of_Champions
FROM
	student.aa_lol_champs AS alc
;
-----------------------------------------------------------------------------------
-- Shows how many champions there are in total!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA3 - How many champions are from each region?
-----------------------------------------------------------------------------------
SELECT 
	count(DISTINCT region)
FROM
	student.aa_lol_champs AS alc
;
SELECT 
	region,
	count(DISTINCT champion) AS No_of_Champions
FROM 
	aa_lol_champs AS alc
GROUP BY
	region 
ORDER BY 
	No_of_Champions DESC;
;
-----------------------------------------------------------------------------------
-- Shows how many champions there are from each region!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA4 - How many champions from each species class?
-----------------------------------------------------------------------------------
SELECT 
	count(DISTINCT species)
FROM
	student.aa_lol_champs AS alc
;

SELECT 
	species,
	count(DISTINCT champion) AS No_of_Champions
FROM 
	aa_lol_champs AS alc
GROUP BY
	species 
ORDER BY 
	No_of_Champions DESC;
;
-----------------------------------------------------------------------------------
-- Shows how many champions there are from each species!!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA5 - What are the different species in Ionia?
-----------------------------------------------------------------------------------
SELECT 
	DISTINCT region,
	species
FROM 
	student.aa_lol_champs AS alc 
WHERE
	region = 'Ionia'
ORDER BY 
	species
;
-----------------------------------------------------------------------------------
-- Shows the different species there residing in Ionia!!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA6 - Who are the Darkin and Aspect Champions?
-----------------------------------------------------------------------------------
SELECT 
	champion,
	species
FROM
	student.aa_lol_champs AS alc
WHERE 
	species LIKE '%Darkin%' 
OR 
	species LIKE '%Aspect%'
GROUP BY
	champion,
	species
ORDER BY 
	species,
	champion
;
-----------------------------------------------------------------------------------
-- The Darkins and the Aspects are two of the strongest species!!  
-- This query shows the champions that are darkins or aspects!!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA7 - What region has the lowest number of champions?
-----------------------------------------------------------------------------------
SELECT 
    region,
    COUNT(DISTINCT champion) AS No_of_Champions
FROM 
    aa_lol_champs AS alc
GROUP BY
    region
ORDER BY 
	No_Of_Champions
LIMIT 
	1
;
-----------------------------------------------------------------------------------
-- This shows which region least amount of champions!!
-----------------------------------------------------------------------------------
SELECT 
    DISTINCT region,
    champion
FROM
    student.aa_lol_champs AS alc 
WHERE 
    region ILIKE '%Before_Runeterra%';
;
-----------------------------------------------------------------------------------
-- Found out its actually Aurelion Sol who is known to be the actual creator 
-- of everything in Runeterra!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA8 - What are the different classes and how many champions are in each class?
-----------------------------------------------------------------------------------
SELECT
	DISTINCT "class",
	count(DISTINCT champion) AS No_Of_Champions
FROM
	student.aa_lol_champs AS alc 
GROUP BY
	"class"
ORDER BY 
	No_of_Champions DESC 
;
-----------------------------------------------------------------------------------
-- This shows the number of champions in each class!!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA9 - Who are all the highest tier champions in the oldest patch?
------- Order champions alphabetically A-Z
-----------------------------------------------------------------------------------
SELECT 
	patch,
	champion,
	tier
FROM
	student.aa_lol_champs AS alc
WHERE 
	tier = 'God'
AND 
	patch = (
	SELECT 
		min(patch)
	FROM
		student.aa_lol_champs
			) 
GROUP BY 
	patch,
	champion,
	tier
ORDER BY 
	champion 
;
-----------------------------------------------------------------------------------
-- This lists all the the champions that were considered the best to play
-- in the oldest patch of the year!! Playing these champs in that patch
-- would mean you have a higher chance of winning based on the statistics!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA10 - What roles have the highest popularity from all the patches in 2023?
-----------------------------------------------------------------------------------
SELECT
	"role",
	max(pick_rate) AS pick_rate_
FROM 
	student.aa_lol_champs AS alc
WHERE 
	"year" = 2023
GROUP BY
	"role"
ORDER BY
	pick_rate_ DESC,
	"role"
;
-----------------------------------------------------------------------------------
-- This lists the most popular roles in the patches in year 2023, meaning the roles
-- that were most played!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA11 - Can you name the lowest winrate champion for each patch?
-------- Order by lowest winrate at the top
-----------------------------------------------------------------------------------
SELECT DISTINCT ON (patch)
    patch,
    champion,
    win_rate
FROM
    student.aa_lol_champs AS alc
ORDER BY
    patch,
    win_rate
;
-----------------------------------------------------------------------------------
-- This the champion with the lowest win rate from each individual patch, showing
-- that that champion had the most losses in total from that patch!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA12 - Which champions had an average rating above 70 in 2023?
-------- Order by highest rating
-----------------------------------------------------------------------------------
SELECT 
	champion,
	avg(rating) AS avg_rating
FROM
	student.aa_lol_champs AS alc
WHERE 
	"year" = 2023
GROUP BY 
	champion 
HAVING 
	avg(rating) > 70
ORDER BY 
	avg_rating DESC,
	champion
;
-----------------------------------------------------------------------------------
-- This shows the average score of each champion from the year 2023, showing the
-- champion that had the highest user rating from all the patches in 2023
-- combined!! It may not be accurate as it depends on the sample size of each
-- champion rated but overall it shows the most rated champions!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA13 - Which champions had positive winrate in the latest patch?
-------- List the name, patch, region, species and class of the champions.
-------- Order by highest winrate, then champion.
-----------------------------------------------------------------------------------
SELECT 
	patch,
	champion,
	region,
	species,
	"class",
	win_rate
FROM
	student.aa_lol_champs AS alc
WHERE 
	patch = (
	SELECT 
		max(patch)
	FROM
		student.aa_lol_champs
			) 
AND 
	win_rate > 50
ORDER BY
	win_rate DESC,
	champion
;
-----------------------------------------------------------------------------------
-- This shows the champions with the highest winrate from the most recent patch,
-- this data can be used right now to pick the champions you want, the highest
-- winrate champs will increase your odds of winning!! It also shows cool info
-- on the champions background!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA14 - Which champions winrate increased by atleast 10% over patches?
-------- Order by champions then patch
-----------------------------------------------------------------------------------
WITH champion_win_rate AS (
    SELECT
        champion,
        patch,
        min(win_rate) AS initial_win_rate,
        max(win_rate) AS final_win_rate
    FROM
        student.aa_lol_champs
    GROUP BY
        champion, patch
							)
SELECT
    champion,
    patch,
    initial_win_rate,
    final_win_rate
FROM
    champion_win_rate
WHERE
    (final_win_rate - initial_win_rate) / initial_win_rate >= 0.1
ORDER BY
    champion,
   	patch
;
-----------------------------------------------------------------------------------
-- This shows the the champions that have the best increase in winrate over patches
-- Certain champions get buffs over patches and sometimes they get buffed too
-- much, so this shows which champions winrate increased drastically meaning
-- they were buffed too much and got played alot to increase users wins!!
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--AA15 - Which species in each regions are most played and least played?
-------- Order by least played first then if tie, regions
-----------------------------------------------------------------------------------
WITH species_count AS (
	SELECT 
		region,
		species,
		count(DISTINCT champion) AS No_of_Champions
	FROM
		student.aa_lol_champs AS alc
	GROUP BY
		region,
		species
						)
SELECT 
	region,
	species,
	No_of_Champions,
	DENSE_RANK() OVER(PARTITION BY region ORDER BY No_Of_Champions DESC) AS Species_Rank
FROM 
	species_count
ORDER BY
	region,
	Species_Rank
;
-----------------------------------------------------------------------------------
-- This shows the different species from each region and shows the ones that 
-- are most prevelant in that region and ranks them, so we know now that there
-- are 4 Humans from bildgewater ranked number 1 as that is the highest amount
-- for species!! It also ties the rank because some of the number of champions
-- are the same!! It lets me know that there are 2 shapeshifters from ixtal tied
-- with 2 magic_humans!!!!
-----------------------------------------------------------------------------------





